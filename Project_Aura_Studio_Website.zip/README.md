# Project Aura Studio Website

A static HTML/CSS/JS website for Project Aura Studio.

## Files
- `index.html` — website structure/content
- `style.css` — responsive styling
- `script.js` — menu + scroll reveal animations

## Publish on GitHub Pages
1. Create a public GitHub repository.
2. Upload all three files.
3. Go to Settings → Pages.
4. Choose "Deploy from a branch".
5. Select `main` and `/ (root)`.
6. Save.

The site uses a Google Font, so internet access is needed for the font. Everything else is local.

## Current links
Animal RNG:
https://www.roblox.com/share?code=a9e2eb8495b35b4cba8c259832231c38&type=ExperienceDetails&stamp=1790073760539

Discord contact:
https://discord.com/users/1447141395600248923
